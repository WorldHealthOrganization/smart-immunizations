# Library - WHO Immunization Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* [**IMMZ.D5.DT.JE contraindications**](PlanDefinition-IMMZD5DTJEContraindications.md)
* **Library**

## Library: Library 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/immunizations/PlanDefinition/IMMZD5DTJEContraindications#effective-data-requirements | *Version*:0.2.0 |
| Draft | *Computable Name*:EffectiveDataRequirements |

