# IMMZ.Z.DE15 ValueSet for Rabies vaccines - WHO Immunization Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **IMMZ.Z.DE15 ValueSet for Rabies vaccines**

## ValueSet: IMMZ.Z.DE15 ValueSet for Rabies vaccines 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/immunizations/ValueSet/IMMZ.Z.DE15 | *Version*:1.0.0 |
| Active as of 2026-04-09 | *Computable Name*:IMMZ_Z_DE15 |

 
ValueSet for Rabies vaccines for IMMZ.Z.DE15 

 **References** 

* Included into [IMMZ_Z_VS](ValueSet-IMMZ.Z.VS.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

## API Information

##### IMMZ.Z.DE15 ValueSet for Rabies vaccines Schema API

JSON Schema for IMMZ.Z.DE15 ValueSet for Rabies vaccines ValueSet codes. Generated from FHIR expansions using IRI format.

**Version:** 1.0.0

## Endpoints

### GET /ValueSet-IMMZ.Z.DE15.schema.json

#### JSON Schema definition for the enumeration ValueSet-IMMZ.Z.DE15

This endpoint serves the JSON Schema definition for the enumeration ValueSet-IMMZ.Z.DE15.

## Schema Definition

### ValueSet-IMMZ.Z.DE15

**Description:** JSON Schema for IMMZ.Z.DE15 ValueSet for Rabies vaccines ValueSet codes. Generated from FHIR expansions using IRI format.

**Type:** string

**This documentation is automatically generated from the OpenAPI specification.**



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "IMMZ.Z.DE15",
  "url" : "http://smart.who.int/immunizations/ValueSet/IMMZ.Z.DE15",
  "version" : "1.0.0",
  "name" : "IMMZ_Z_DE15",
  "title" : "IMMZ.Z.DE15 ValueSet for Rabies vaccines",
  "status" : "active",
  "date" : "2026-04-09T13:50:16+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "ValueSet for Rabies vaccines for IMMZ.Z.DE15",
  "compose" : {
    "include" : [{
      "system" : "http://smart.who.int/immunizations/CodeSystem/IMMZ.Z",
      "concept" : [{
        "code" : "DE15",
        "display" : "Rabies vaccines"
      }]
    },
    {
      "system" : "http://id.who.int/icd/release/11/mms",
      "concept" : [{
        "code" : "XM6T09",
        "display" : "Rabies vaccine"
      },
      {
        "code" : "XM7BE8",
        "display" : "Rabies, inactivated, whole virus"
      }]
    },
    {
      "system" : "http://snomed.info/sct",
      "concept" : [{
        "code" : "836393002",
        "display" : "Rabies lyssavirus antigen-containing vaccine product"
      },
      {
        "code" : "1131000221109",
        "display" : "Vaccine product containing only inactivated whole Rabies lyssavirus antigen"
      }]
    },
    {
      "system" : "http://www.whocc.no/atc",
      "concept" : [{
        "code" : "J07BG",
        "display" : "Rabies vaccines"
      },
      {
        "code" : "J07BG01",
        "display" : "Rabies, inactivated, whole virus"
      }]
    }]
  }
}

```
