# Immunization Other Important Medical Event - WHO Immunization Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **Immunization Other Important Medical Event**

## Extension: Immunization Other Important Medical Event 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/immunizations/StructureDefinition/IMMZOtherMedicalEvent | *Version*:1.0.0 |
| Active as of 2026-04-09 | *Computable Name*:IMMZOtherMedicalEvent |

There was another important reaction or medical event

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [SMART Guidelines Immunizations AdverseEvent](StructureDefinition-IMMZ.AdverseEvent.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/smart.who.int.immunizations|current/StructureDefinition/IMMZOtherMedicalEvent)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-IMMZOtherMedicalEvent.csv), [Excel](StructureDefinition-IMMZOtherMedicalEvent.xlsx), [Schematron](StructureDefinition-IMMZOtherMedicalEvent.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "IMMZOtherMedicalEvent",
  "url" : "http://smart.who.int/immunizations/StructureDefinition/IMMZOtherMedicalEvent",
  "version" : "1.0.0",
  "name" : "IMMZOtherMedicalEvent",
  "title" : "Immunization Other Important Medical Event",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-09T13:50:16+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "There was another important reaction or medical event ",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Immunization"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "Immunization Other Important Medical Event",
      "definition" : "There was another important reaction or medical event "
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://smart.who.int/immunizations/StructureDefinition/IMMZOtherMedicalEvent"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
