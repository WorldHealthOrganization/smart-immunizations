# IMMZ.D18.S.DTP.On-time start schedule - WHO Immunization Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **IMMZ.D18.S.DTP.On-time start schedule**

## PlanDefinition: IMMZ.D18.S.DTP.On-time start schedule 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/immunizations/PlanDefinition/IMMZD18SDTPOnTimeStart | *Version*:1.0.0 |
| Draft as of 2026-04-09 | *Computable Name*:IMMZD18SDTPOnTimeStart |

 
IMMZ.D18.S.DTP.On-time start schedule Diphtheria–tetanus–pertussis (DTP) vaccination schedule, on-time start (at ≤ 12 months of age) 

* **Actions: **: **Url: **
  * : [IMMZ.D18.S.DTP.On-time start schedule](PlanDefinition-IMMZD18SDTPOnTimeStart.md)
* **Actions: **: **Version: **
  * : 1.0.0
* **Actions: **: **Title: **
  * : IMMZ.D18.S.DTP.On-time start schedule
* **Actions: **: **Status: **
  * : draft
* **Actions: **: **Date: **
  * : 2026-04-09 13:50:16+0000
* **Actions: **: **Publisher: **
  * : WHO
* **Actions: **: **Description: **
  * : IMMZ.D18.S.DTP.On-time start schedule Diphtheria–tetanus–pertussis (DTP) vaccination schedule, on-time start (at ≤ 12 months of age)
* **Actions: **: **Knowledge Capability: **
  * : computable
* **Actions: **: **Libraries: **
  * : 
| |
| :--- |
| [IMMZD18SDTPOnTimeStartLogic](Library-IMMZD18SDTPOnTimeStartLogic.md) |




## Resource Content

```json
{
  "resourceType" : "PlanDefinition",
  "id" : "IMMZD18SDTPOnTimeStart",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-recommendationdefinition",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareableplandefinition",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishableplandefinition"]
  },
  "contained" : [{
    "resourceType" : "Library",
    "id" : "effective-data-requirements",
    "extension" : [{
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZElements"
      },
      {
        "url" : "name",
        "valueString" : "Doses Administered to Patient"
      },
      {
        "url" : "statement",
        "valueString" : "/**\n * @dataElement All Doses Administered to Patient\n */\ndefine \"Doses Administered to Patient\":\n  [Immunization] I\n    where I.status = 'completed'\n    and I.isSubpotent is not true"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 0
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPElements"
      },
      {
        "url" : "name",
        "valueString" : "DTP Doses Administered to Patient"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: DTP containing Doses Administered to Patient\n*/\ndefine \"DTP Doses Administered to Patient\":\n  Elements.\"Doses Administered to Patient\" I\n  where\n    I.vaccineCode in Concepts.\"DTP-containing vaccines\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 1
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPElements"
      },
      {
        "url" : "name",
        "valueString" : "DTP Primary Series Doses Administered to Patient"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: DTP containing Doses Administered to Patient that are in the Primary series\n*/\ndefine \"DTP Primary Series Doses Administered to Patient\":\n  \"DTP Doses Administered to Patient\".seriesPrimary()"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 2
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "DTP Primary Series Doses Administered to Patient"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: DTP containing Doses Administered to Patient that are in the Primary series\n*/\ndefine \"DTP Primary Series Doses Administered to Patient\":\n  DTPElements.\"DTP Primary Series Doses Administered to Patient\".onOrBefore(Today)"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 3
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "Number of DTP Primary Series Doses Administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: Number of DTP Primary Series doses\n*/\ndefine \"Number of DTP Primary Series Doses Administered\":\n  Count(\"DTP Primary Series Doses Administered to Patient\")"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 4
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "Two DTP primary series doses were administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@input: Two DTP primary series doses were administered\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"DTP-containing vaccines\" and \"Type of dose\" = \"Primary series\") = 2\n@code: Two DTP primary series doses were administered-123\n@decision: IMMZ.D2.DT.DTP.On-time start: DTP vaccination schedule, on-time start (at ≤ 12 months of age)\n@decision: IMMZ.D2.DT.DTP.Delayed or interrupted series: DTP vaccination schedule for the following groups: children ≥ 1 year of age with no previous immunization, adolescents and adults with no previous immunization (including pregnant women) and supplementary immunization activities in high-risk areas, for women of reproductive age\n*/\ndefine \"Two DTP primary series doses were administered\":\n  \"Number of DTP Primary Series Doses Administered\" = 2"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 5
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Second DTP dose from the primary series was administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@complete: Second DTP dose from the primary series was administered\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"DTP-containing vaccines\" and \"Type of dose\" = \"Primary series\") = 2\n*/\ndefine \"Second DTP dose from the primary series was administered\":\n  Encounter.\"Two DTP primary series doses were administered\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 6
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "Three DTP primary series doses were administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@input: Three DTP primary series doses were administered\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"DTP-containing vaccines\" and \"Type of dose\" = \"Primary series\") = 3\n@code: Three DTP primary series doses were administered-123\n@decision: IMMZ.D2.DT.DTP.On-time start: DTP vaccination schedule, on-time start (at ≤ 12 months of age)\n@decision: IMMZ.D2.DT.DTP.Delayed or interrupted series: DTP vaccination schedule for the following groups: children ≥ 1 year of age with no previous immunization, adolescents and adults with no previous immunization (including pregnant women) and supplementary immunization activities in high-risk areas, for women of reproductive age\n@decision: IMMZ.D2.DT.DTP.Pregnancy: Determine whether DTP-containing vaccines are needed for pregnant women\n@decision: IMMZ.D2.DT.DTP.Pregnancy starting with 3 doses: Diphtheria and tetanus vaccination schedule in pregnant women who received 3 childhood DTP doses\n@decision: IMMZ.D2.DT.DTP.Pregnancy starting with 4 doses: Diphtheria and tetanus vaccination schedule in pregnant women who received 4 childhood DTP doses\n*/\ndefine \"Three DTP primary series doses were administered\":\n  \"Number of DTP Primary Series Doses Administered\" = 3"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 7
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Third DTP dose from the primary series was administered. The primary DTP series has been completed"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@complete: Third DTP dose from the primary series was administered. The primary DTP series has been completed\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"DTP-containing vaccines\" and \"Type of dose\" = \"Primary series\") = 3\n\"Completed the primary vaccination series\" = TRUE (where \"Vaccine type\" = \"DTP-containing vaccines\")\n*/\ndefine \"Third DTP dose from the primary series was administered. The primary DTP series has been completed\":\n  Encounter.\"Three DTP primary series doses were administered\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 8
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "DTP dose 3"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: DTP dose 3\n@description: Provision of DTP dose 3\n@trigger: Second DTP dose from the primary series was administered\n@pseudo: Count of vaccines administered (where \"Vaccine type\" = \"DTP-containing vaccines\" and \"Type of dose\" = \"Primary series\" ) = 2\n@triggerDate: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"DTP-containing vaccines\")\n*/\ndefine \"DTP dose 3\":\n  \"Second DTP dose from the primary series was administered\" and\n  not \"Third DTP dose from the primary series was administered. The primary DTP series has been completed\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 9
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "DTP Doses Administered to Patient"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: DTP containing Doses Administered to Patient\n*/\ndefine \"DTP Doses Administered to Patient\":\n  DTPElements.\"DTP Doses Administered to Patient\".onOrBefore(Today)"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 10
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "Date of Latest DTP Dose"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: Date of Latest DTP Dose\n*/\ndefine \"Date of Latest DTP Dose\":\n  date from start of \"DTP Doses Administered to Patient\".mostRecent().occurrence.toInterval()"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 11
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "DTP dose 3 Due Date"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: DTP dose 3 Due Date\n@pseudocode: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"DTP-containing vaccines\") + 4 weeks\n*/\ndefine \"DTP dose 3 Due Date\":\n  if \"DTP dose 3\" then Encounter.\"Date of Latest DTP Dose\" + 4 weeks\n  else null"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 12
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "DTP dose 3 Overdue"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: DTP dose 3 Overdue\n@pseudocode: \"Date of birth\" + 6 months\n*/\ndefine \"DTP dose 3 Overdue\":\n  if \"DTP dose 3\" then Patient.birthDate + 6 months\n  else null"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 13
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "DTP dose 3 Create"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: DTP dose 3 Create\n@create: DTP dose 3 should be provided if the client received the previous dose more than 4 weeks ago.\n*/\ndefine \"DTP dose 3 Create\":\n  if \"DTP dose 3\"\n  then 'DTP dose 3 should be provided if the client received the previous dose more than 4 weeks ago.' + '\nDue Date: ' + ToString(\"DTP dose 3 Due Date\") + '\nOverdue: ' + ToString(\"DTP dose 3 Overdue\")\n  else ''"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 14
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "No DTP primary series doses were administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@input: No DTP primary series doses were administered\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"DTP-containing vaccines\" and \"Type of dose\" = \"Primary series\") = 0\n@code: No DTP primary series doses were administered-123\n@decision: IMMZ.D2.DT.DTP.On-time start: DTP vaccination schedule, on-time start (at ≤ 12 months of age)\n@decision: IMMZ.D2.DT.DTP.Delayed or interrupted series: DTP vaccination schedule for the following groups: children ≥ 1 year of age with no previous immunization, adolescents and adults with no previous immunization (including pregnant women) and supplementary immunization activities in high-risk areas, for women of reproductive age\n@decision: IMMZ.D2.DT.DTP.Pregnancy: Determine whether DTP-containing vaccines are needed for pregnant women\n*/\ndefine \"No DTP primary series doses were administered\":\n  \"Number of DTP Primary Series Doses Administered\" = 0"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 15
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "DTP dose 1 Expiration"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: DTP dose 1 Expiration\n@pseudocode: \"Date of birth\" + 1 year\n*/\ndefine \"DTP dose 1 Expiration\":\n  Patient.birthDate + 1 year"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 16
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "DTP dose 1"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: DTP dose 1\n@description: Provision of DTP dose 1\n@trigger: Child's birth\n@pseudo: \n@triggerDate: \"Date of birth\"\n*/\ndefine \"DTP dose 1\":\n  Encounter.\"No DTP primary series doses were administered\"\n  and \"DTP dose 1 Expiration\" after day of Today"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 17
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "DTP dose 1 Due Date"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: DTP dose 1 Due Date\n@pseudocode: \"Date of birth\" + 6 weeks\n*/\ndefine \"DTP dose 1 Due Date\":\n  if \"DTP dose 1\" then Patient.birthDate + 6 weeks\n  else null"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 18
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "DTP dose 1 Create"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: DTP dose 1 Create\n@create: DTP dose 1 should be provided if the client is older than 6 weeks of age.\n*/\ndefine \"DTP dose 1 Create\":\n  if \"DTP dose 1\"\n  then 'DTP dose 1 should be provided if the client is older than 6 weeks of age.' + '\nDue Date: ' + ToString(\"DTP dose 1 Due Date\") + '\nExpiration: ' + ToString(\"DTP dose 1 Expiration\")\n  else ''"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 19
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "Current Patient Age In Years"
      },
      {
        "url" : "statement",
        "valueString" : "/** \n * @dataElement Patient age in years\n */\ndefine \"Current Patient Age In Years\":\n  AgeInYearsAt(Today)"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 20
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "Client's age is between 1 year and 6 years"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@input: Client's age is between 1 year and 6 years\n@pseudocode: 1 year ≤ Today's date − \"Date of birth\" ≤ 6 years\n@code: Client's age is between 1 year and 6 years-49\n@decision: IMMZ.D2.DT.DTP.On-time start: DTP vaccination schedule, on-time start (at ≤ 12 months of age)\n@decision: IMMZ.D2.DT.DTP.Delayed or interrupted series: DTP vaccination schedule for the following groups: children ≥ 1 year of age with no previous immunization, adolescents and adults with no previous immunization (including pregnant women) and supplementary immunization activities in high-risk areas, for women of reproductive age\n*/\ndefine \"Client's age is between 1 year and 6 years\":\n  1 <= Encounter.\"Current Patient Age In Years\"\n  and Encounter.\"Current Patient Age In Years\" <= 6"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 21
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPElements"
      },
      {
        "url" : "name",
        "valueString" : "Pertussis Doses Administered to Patient"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: Pertussis Doses Administered to Patient\n*/\ndefine \"Pertussis Doses Administered to Patient\":\n  Elements.\"Doses Administered to Patient\" I\n  where\n    I.vaccineCode in Concepts.\"Pertussis-containing vaccines\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 22
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPElements"
      },
      {
        "url" : "name",
        "valueString" : "Pertussis Booster Series Doses Administered to Patient"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: Pertussis Booster Series Doses Administered to Patient\n*/\ndefine \"Pertussis Booster Series Doses Administered to Patient\":\n  \"Pertussis Doses Administered to Patient\".seriesBooster()"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 23
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "Pertussis Booster Series Doses Administered to Patient"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: Pertussis Booster Series Doses Administered to Patient\n*/\ndefine \"Pertussis Booster Series Doses Administered to Patient\":\n  DTPElements.\"Pertussis Booster Series Doses Administered to Patient\".onOrBefore(Today)"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 24
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "Number of Pertussis Booster Series Doses Administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: Number of Pertussis Booster Series Doses Administered\n*/\ndefine \"Number of Pertussis Booster Series Doses Administered\":\n  Count(\"Pertussis Booster Series Doses Administered to Patient\")"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 25
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "One pertussis booster dose was administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@input: One pertussis booster dose was administered\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"Pertussis-containing vaccines\" and \"Type of dose\" = \"Booster dose\") = 1\n@code: One pertussis booster dose was administered-127\n@decision: IMMZ.D2.DT.DTP.On-time start: DTP vaccination schedule, on-time start (at ≤ 12 months of age)\n@decision: IMMZ.D2.DT.DTP.Delayed or interrupted series: DTP vaccination schedule for the following groups: children ≥ 1 year of age with no previous immunization, adolescents and adults with no previous immunization (including pregnant women) and supplementary immunization activities in high-risk areas, for women of reproductive age\n*/\ndefine \"One pertussis booster dose was administered\":\n  \"Number of Pertussis Booster Series Doses Administered\" = 1"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 26
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Pertussis-containing booster dose was administered. Pertussis immunization schedule has been completed"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@complete: Pertussis-containing booster dose was administered. Pertussis immunization schedule has been completed\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"Pertussis-containing vaccines\" and \"Type of dose\" = \"Booster dose\") = 1\n\"Immunization recommendation status\" = \"Complete\" (where \"Vaccine type\" = \"Pertussis-containing vaccines\")\n*/\ndefine \"Pertussis-containing booster dose was administered. Pertussis immunization schedule has been completed\":\n  Encounter.\"One pertussis booster dose was administered\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 27
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Pertussis-containing vaccine booster dose Expiration"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: Pertussis-containing vaccine booster dose Expiration\n@pseudocode: \"Date of birth\" + 7 years\n*/\ndefine \"Pertussis-containing vaccine booster dose Expiration\":\n  Patient.birthDate + 7 years"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 28
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Pertussis-containing vaccine booster dose"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: Pertussis-containing vaccine booster dose\n@description: Provision of the pertussis-containing vaccine booster dose\n@trigger: The primary DTP series has been completed and client's age is between 1 and 6 years\n@pseudo: \"Completed the primary vaccination series\" = TRUE (where \"Vaccine type\" = \"DTP-containing vaccines\") AND 1 year ≤ Today's date − \"Date of birth\" ≤ 6 years\n@triggerDate: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"DTP-containing vaccines\")\n*/\ndefine \"Pertussis-containing vaccine booster dose\":\n  \"Third DTP dose from the primary series was administered. The primary DTP series has been completed\" and\n  Encounter.\"Client's age is between 1 year and 6 years\" and\n  not \"Pertussis-containing booster dose was administered. Pertussis immunization schedule has been completed\"\n  and \"Pertussis-containing vaccine booster dose Expiration\" after day of Today"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 29
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Pertussis-containing vaccine booster dose Due Date"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: Pertussis-containing vaccine booster dose Due Date\n@pseudocode: Date of birth\" + 1 'year' OR Latest \"Date and time of vaccination\" where \"Vaccine type\" = \"DTP-containing vaccines\" + 6 months\n*/\ndefine \"Pertussis-containing vaccine booster dose Due Date\":\n  if \"Pertussis-containing vaccine booster dose\"\n  then WC.LatestOf({ Patient.birthDate + 1 year, Encounter.\"Date of Latest DTP Dose\" + 6 months })\n  else null"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 30
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Pertussis-containing vaccine booster dose Overdue"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: Pertussis-containing vaccine booster dose Overdue\n@pseudocode: \"Date of birth\" + 7 years\n*/\ndefine \"Pertussis-containing vaccine booster dose Overdue\":\n  if \"Pertussis-containing vaccine booster dose\" then Patient.birthDate + 7 years\n  else null"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 31
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Pertussis-containing vaccine booster dose Create"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: Pertussis-containing vaccine booster dose Create\n@create: A booster dose is recommended for children aged 1–6 years, preferably during the second year of life (≥6 months after last primary dose).\n*/\ndefine \"Pertussis-containing vaccine booster dose Create\":\n  if \"Pertussis-containing vaccine booster dose\"\n  then 'A booster dose is recommended for children aged 1–6 years, preferably during the second year of life (≥6 months after last primary dose).' + '\nDue Date: ' + ToString(\"Pertussis-containing vaccine booster dose Due Date\") + '\nOverdue: ' + ToString(\"Pertussis-containing vaccine booster dose Overdue\") + '\nExpiration: ' + ToString(\"Pertussis-containing vaccine booster dose Expiration\")\n  else ''"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 32
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "One DTP primary series dose was administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@input: One DTP primary series dose was administered\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"DTP-containing vaccines\" and \"Type of dose\" = \"Primary series\") = 1\n@code: One DTP primary series dose was administered-123\n@decision: IMMZ.D2.DT.DTP.On-time start: DTP vaccination schedule, on-time start (at ≤ 12 months of age)\n@decision: IMMZ.D2.DT.DTP.Delayed or interrupted series: DTP vaccination schedule for the following groups: children ≥ 1 year of age with no previous immunization, adolescents and adults with no previous immunization (including pregnant women) and supplementary immunization activities in high-risk areas, for women of reproductive age\n*/\ndefine \"One DTP primary series dose was administered\":\n  \"Number of DTP Primary Series Doses Administered\" = 1"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 33
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "First DTP dose from the primary series was administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@complete: First DTP dose from the primary series was administered\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"DTP-containing vaccines\" and \"Type of dose\" = \"Primary series\") = 1\n*/\ndefine \"First DTP dose from the primary series was administered\":\n  Encounter.\"One DTP primary series dose was administered\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 34
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "DTP dose 2"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: DTP dose 2\n@description: Provision of DTP dose 2\n@trigger: First DTP dose from the primary series was administered\n@pseudo: Count of vaccines administered (where \"Vaccine type\" = \"DTP-containing vaccines\" and \"Type of dose\" = \"Primary series\") = 1\n@triggerDate: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"DTP-containing vaccines\")\n*/\ndefine \"DTP dose 2\":\n  \"First DTP dose from the primary series was administered\" and\n  not \"Second DTP dose from the primary series was administered\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 35
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "DTP dose 2 Due Date"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: DTP dose 2 Due Date\n@pseudocode: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"DTP-containing vaccines\") + 4 weeks\n*/\ndefine \"DTP dose 2 Due Date\":\n  if \"DTP dose 2\" then Encounter.\"Date of Latest DTP Dose\" + 4 weeks\n  else null"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 36
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "DTP dose 2 Overdue"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: DTP dose 2 Overdue\n@pseudocode: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"DTP-containing vaccines\") + 8 weeks\n*/\ndefine \"DTP dose 2 Overdue\":\n  if \"DTP dose 2\" then Encounter.\"Date of Latest DTP Dose\" + 8 weeks\n  else null"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 37
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "DTP dose 2 Create"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: DTP dose 2 Create\n@create: DTP dose 2 should be provided if the client was given the previous DTP dose more than 4 weeks ago.\n*/\ndefine \"DTP dose 2 Create\":\n  if \"DTP dose 2\"\n  then 'DTP dose 2 should be provided if the client was given the previous DTP dose more than 4 weeks ago.' + '\nDue Date: ' + ToString(\"DTP dose 2 Due Date\") + '\nOverdue: ' + ToString(\"DTP dose 2 Overdue\")\n  else ''"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 38
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPElements"
      },
      {
        "url" : "name",
        "valueString" : "Td Doses Administered to Patient"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: Td Doses Administered to Patient\n*/\ndefine \"Td Doses Administered to Patient\":\n  Elements.\"Doses Administered to Patient\" I\n  where\n    I.vaccineCode in Concepts.\"Tetanus and diphtheria-containing vaccines\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 39
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPElements"
      },
      {
        "url" : "name",
        "valueString" : "Td Booster Series Doses Administered to Patient"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: Td Booster Series Doses Administered to Patient\n*/\ndefine \"Td Booster Series Doses Administered to Patient\":\n  \"Td Doses Administered to Patient\".seriesBooster()"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 40
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "Td Booster Series Doses Administered to Patient"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: Td Booster Series Doses Administered to Patient\n*/\ndefine \"Td Booster Series Doses Administered to Patient\":\n  DTPElements.\"Td Booster Series Doses Administered to Patient\".onOrBefore(Today)"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 41
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "Number of Td Booster Series Doses Administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@internal: Number of Td Booster Series Doses Administered\n*/\ndefine \"Number of Td Booster Series Doses Administered\":\n  Count(\"Td Booster Series Doses Administered to Patient\")"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 42
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "One tetanus and diphtheria booster dose was administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@input: One tetanus and diphtheria booster dose was administered\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\" and \"Type of dose\" = \"Booster dose\") = 1\n@code: One tetanus and diphtheria booster dose was administered-140\n@decision: IMMZ.D2.DT.DTP.On-time start: DTP vaccination schedule, on-time start (at ≤ 12 months of age)\n@decision: IMMZ.D2.DT.DTP.Delayed or interrupted series: DTP vaccination schedule for the following groups: children ≥ 1 year of age with no previous immunization, adolescents and adults with no previous immunization (including pregnant women) and supplementary immunization activities in high-risk areas, for women of reproductive age\n@decision: IMMZ.D2.DT.DTP.Pregnancy: Determine whether DTP-containing vaccines are needed for pregnant women\n@decision: IMMZ.D2.DT.DTP.Pregnancy starting with 4 doses: Diphtheria and tetanus vaccination schedule in pregnant women who received 4 childhood DTP doses\n*/\ndefine \"One tetanus and diphtheria booster dose was administered\":\n  \"Number of Td Booster Series Doses Administered\" = 1"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 43
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "First tetanus and diphtheria booster dose was administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@complete: First tetanus and diphtheria booster dose was administered\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\" and \"Type of dose\" = \"Booster dose\") = 1\n*/\ndefine \"First tetanus and diphtheria booster dose was administered\":\n  Encounter.\"One tetanus and diphtheria booster dose was administered\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 44
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "Two tetanus and diphtheria booster doses were administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@input: Two tetanus and diphtheria booster doses were administered\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\" and \"Type of dose\" = \"Booster dose\") = 2\n@code: Two tetanus and diphtheria booster doses were administered-140\n@decision: IMMZ.D2.DT.DTP.On-time start: DTP vaccination schedule, on-time start (at ≤ 12 months of age)\n@decision: IMMZ.D2.DT.DTP.Delayed or interrupted series: DTP vaccination schedule for the following groups: children ≥ 1 year of age with no previous immunization, adolescents and adults with no previous immunization (including pregnant women) and supplementary immunization activities in high-risk areas, for women of reproductive age\n@decision: IMMZ.D2.DT.DTP.Pregnancy: Determine whether DTP-containing vaccines are needed for pregnant women\n@decision: IMMZ.D2.DT.DTP.Pregnancy starting with 3 doses: Diphtheria and tetanus vaccination schedule in pregnant women who received 3 childhood DTP doses\n@decision: IMMZ.D2.DT.DTP.Pregnancy starting with 4 doses: Diphtheria and tetanus vaccination schedule in pregnant women who received 4 childhood DTP doses\n*/\ndefine \"Two tetanus and diphtheria booster doses were administered\":\n  \"Number of Td Booster Series Doses Administered\" = 2"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 45
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Second tetanus and diphtheria booster dose was administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@complete: Second tetanus and diphtheria booster dose was administered\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\" and \"Type of dose\" = \"Booster dose\") = 2\n*/\ndefine \"Second tetanus and diphtheria booster dose was administered\":\n  Encounter.\"Two tetanus and diphtheria booster doses were administered\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 46
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Tetanus and diphtheria-containing vaccine booster dose 2"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: Tetanus and diphtheria-containing vaccine booster dose 2\n@description: Provision of tetanus and diphtheria booster dose 2\n@trigger: First tetanus and diphtheria booster dose was administered\n@pseudo: Count of vaccines administered (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\" and \"Type of dose\" = \"Booster dose\") = 1\n@triggerDate: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\")\n*/\ndefine \"Tetanus and diphtheria-containing vaccine booster dose 2\":\n  \"First tetanus and diphtheria booster dose was administered\" and\n  not \"Second tetanus and diphtheria booster dose was administered\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 47
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Tetanus and diphtheria-containing vaccine booster dose 2 Due Date"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: Tetanus and diphtheria-containing vaccine booster dose 2 Due Date\n@pseudocode: \"Date of birth\" + 4 years\n*/\ndefine \"Tetanus and diphtheria-containing vaccine booster dose 2 Due Date\":\n  if \"Tetanus and diphtheria-containing vaccine booster dose 2\" then Patient.birthDate + 4 years\n  else null"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 48
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Tetanus and diphtheria-containing vaccine booster dose 2 Overdue"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: Tetanus and diphtheria-containing vaccine booster dose 2 Overdue\n@pseudocode: \"Date of birth\" + 8 years\n*/\ndefine \"Tetanus and diphtheria-containing vaccine booster dose 2 Overdue\":\n  if \"Tetanus and diphtheria-containing vaccine booster dose 2\" then Patient.birthDate + 8 years\n  else null"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 49
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Tetanus and diphtheria-containing vaccine booster dose 2 Create"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: Tetanus and diphtheria-containing vaccine booster dose 2 Create\n@create: Three booster doses of diphtheria-containing vaccine should be provided during childhood and adolescence. The diphtheria booster doses should be given in combination with tetanus using the same schedule (i.e at 12–23 months of age, 4–7 years of age and 9–15 years of age, using age-appropriate vaccine formulations). Ideally, there should be at least 4 years between booster doses. Member States may update this schedule based on their country context.\n*/\ndefine \"Tetanus and diphtheria-containing vaccine booster dose 2 Create\":\n  if \"Tetanus and diphtheria-containing vaccine booster dose 2\"\n  then 'Three booster doses of diphtheria-containing vaccine should be provided during childhood and adolescence. The diphtheria booster doses should be given in combination with tetanus using the same schedule (i.e at 12–23 months of age, 4–7 years of age and 9–15 years of age, using age-appropriate vaccine formulations). Ideally, there should be at least 4 years between booster doses. Member States may update this schedule based on their country context.' + '\nDue Date: ' + ToString(\"Tetanus and diphtheria-containing vaccine booster dose 2 Due Date\") + '\nOverdue: ' + ToString(\"Tetanus and diphtheria-containing vaccine booster dose 2 Overdue\")\n  else ''"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 50
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "No tetanus and diphtheria booster doses were administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@input: No tetanus and diphtheria booster doses were administered\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\" and \"Type of dose\" = \"Booster dose\") = 0\n@code: No tetanus and diphtheria booster doses were administered-140\n@decision: IMMZ.D2.DT.DTP.On-time start: DTP vaccination schedule, on-time start (at ≤ 12 months of age)\n@decision: IMMZ.D2.DT.DTP.Delayed or interrupted series: DTP vaccination schedule for the following groups: children ≥ 1 year of age with no previous immunization, adolescents and adults with no previous immunization (including pregnant women) and supplementary immunization activities in high-risk areas, for women of reproductive age\n@decision: IMMZ.D2.DT.DTP.Pregnancy starting with 3 doses: Diphtheria and tetanus vaccination schedule in pregnant women who received 3 childhood DTP doses\n*/\ndefine \"No tetanus and diphtheria booster doses were administered\":\n  \"Number of Td Booster Series Doses Administered\" = 0"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 51
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Tetanus and diphtheria-containing vaccine booster dose 1"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: Tetanus and diphtheria-containing vaccine booster dose 1\n@description: Provision of tetanus and diphtheria booster dose 1\n@trigger: The primary DTP series has been completed\n@pseudo: \"Completed the primary vaccination series\" = TRUE (where \"Vaccine type\" = \"DTP-containing vaccines\")\n@triggerDate: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"DTP-containing vaccines\")\n*/\ndefine \"Tetanus and diphtheria-containing vaccine booster dose 1\":\n  \"Third DTP dose from the primary series was administered. The primary DTP series has been completed\" and\n  Encounter.\"No tetanus and diphtheria booster doses were administered\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 52
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Tetanus and diphtheria-containing vaccine booster dose 1 Due Date"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: Tetanus and diphtheria-containing vaccine booster dose 1 Due Date\n@pseudocode: \"Date of birth\" + 12 months\n*/\ndefine \"Tetanus and diphtheria-containing vaccine booster dose 1 Due Date\":\n  if \"Tetanus and diphtheria-containing vaccine booster dose 1\" then Patient.birthDate + 12 months\n  else null"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 53
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Tetanus and diphtheria-containing vaccine booster dose 1 Overdue"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: Tetanus and diphtheria-containing vaccine booster dose 1 Overdue\n@pseudocode: \"Date of birth\" + 24 months\n*/\ndefine \"Tetanus and diphtheria-containing vaccine booster dose 1 Overdue\":\n  if \"Tetanus and diphtheria-containing vaccine booster dose 1\" then Patient.birthDate + 24 months\n  else null"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 54
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Tetanus and diphtheria-containing vaccine booster dose 1 Create"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: Tetanus and diphtheria-containing vaccine booster dose 1 Create\n@create: Three booster doses of diphtheria-containing vaccine should be provided during childhood and adolescence. The diphtheria booster doses should be given in combination with tetanus using the same schedule (i.e at 12–23 months of age, 4–7 years of age and 9–15 years of age, using age-appropriate vaccine formulations). Ideally, there should be at least 4 years between booster doses. Member States may update this schedule based on their country context.\n*/\ndefine \"Tetanus and diphtheria-containing vaccine booster dose 1 Create\":\n  if \"Tetanus and diphtheria-containing vaccine booster dose 1\"\n  then 'Three booster doses of diphtheria-containing vaccine should be provided during childhood and adolescence. The diphtheria booster doses should be given in combination with tetanus using the same schedule (i.e at 12–23 months of age, 4–7 years of age and 9–15 years of age, using age-appropriate vaccine formulations). Ideally, there should be at least 4 years between booster doses. Member States may update this schedule based on their country context.' + '\nDue Date: ' + ToString(\"Tetanus and diphtheria-containing vaccine booster dose 1 Due Date\") + '\nOverdue: ' + ToString(\"Tetanus and diphtheria-containing vaccine booster dose 1 Overdue\")\n  else ''"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 55
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD2DTDTPEncounterElements"
      },
      {
        "url" : "name",
        "valueString" : "Three tetanus and diphtheria booster doses were administered"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@input: Three tetanus and diphtheria booster doses were administered\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\" and \"Type of dose\" = \"Booster dose\") = 3\n@code: Three tetanus and diphtheria booster doses were administered-140\n@decision: IMMZ.D2.DT.DTP.On-time start: DTP vaccination schedule, on-time start (at ≤ 12 months of age)\n@decision: IMMZ.D2.DT.DTP.Pregnancy: Determine whether DTP-containing vaccines are needed for pregnant women\n@decision: IMMZ.D2.DT.DTP.Pregnancy starting with 3 doses: Diphtheria and tetanus vaccination schedule in pregnant women who received 3 childhood DTP doses\n@decision: IMMZ.D2.DT.DTP.Pregnancy starting with 4 doses: Diphtheria and tetanus vaccination schedule in pregnant women who received 4 childhood DTP doses\n*/\ndefine \"Three tetanus and diphtheria booster doses were administered\":\n  \"Number of Td Booster Series Doses Administered\" = 3"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 56
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Third tetanus and diphtheria booster dose was administered. Tetanus and diphtheria immunization schedule has been completed"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@complete: Third tetanus and diphtheria booster dose was administered. Tetanus and diphtheria immunization schedule has been completed\n@pseudocode: Count of vaccines administered (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\" and \"Type of dose\" = \"Booster dose\") = 3\n\"Immunization recommendation status\" = \"Complete\" (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\")\n*/\ndefine \"Third tetanus and diphtheria booster dose was administered. Tetanus and diphtheria immunization schedule has been completed\":\n  Encounter.\"Three tetanus and diphtheria booster doses were administered\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 57
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Tetanus and diphtheria-containing vaccine booster dose 3"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: Tetanus and diphtheria-containing vaccine booster dose 3\n@description: Provision of tetanus and diphtheria booster dose 3\n@trigger: Second tetanus and diphtheria booster dose was administered\n@pseudo: Count of vaccines administered (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\" and \"Type of dose\" = \"Booster dose\") = 2\n@triggerDate: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\")\n*/\ndefine \"Tetanus and diphtheria-containing vaccine booster dose 3\":\n  \"Second tetanus and diphtheria booster dose was administered\" and\n  not \"Third tetanus and diphtheria booster dose was administered. Tetanus and diphtheria immunization schedule has been completed\""
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 58
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Tetanus and diphtheria-containing vaccine booster dose 3 Due Date"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: Tetanus and diphtheria-containing vaccine booster dose 3 Due Date\n@pseudocode: \"Date of birth\" + 9 years\n*/\ndefine \"Tetanus and diphtheria-containing vaccine booster dose 3 Due Date\":\n  if \"Tetanus and diphtheria-containing vaccine booster dose 3\" then Patient.birthDate + 9 years\n  else null"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 59
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Tetanus and diphtheria-containing vaccine booster dose 3 Overdue"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@dynamicValue: Tetanus and diphtheria-containing vaccine booster dose 3 Overdue\n@pseudocode: \"Date of birth\" + 16 years\n*/\ndefine \"Tetanus and diphtheria-containing vaccine booster dose 3 Overdue\":\n  if \"Tetanus and diphtheria-containing vaccine booster dose 3\" then Patient.birthDate + 16 years\n  else null"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 60
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZD18SDTPOnTimeStartLogic"
      },
      {
        "url" : "name",
        "valueString" : "Tetanus and diphtheria-containing vaccine booster dose 3 Create"
      },
      {
        "url" : "statement",
        "valueString" : "/*\n@output: Tetanus and diphtheria-containing vaccine booster dose 3 Create\n@create: Three booster doses of diphtheria-containing vaccine should be provided during childhood and adolescence. The diphtheria booster doses should be given in combination with tetanus using the same schedule (i.e at 12–23 months of age, 4–7 years of age and 9–15 years of age, using age-appropriate vaccine formulations). Ideally, there should be at least 4 years between booster doses. Member States may update this schedule based on their country context.\n*/\ndefine \"Tetanus and diphtheria-containing vaccine booster dose 3 Create\":\n  if \"Tetanus and diphtheria-containing vaccine booster dose 3\"\n  then 'Three booster doses of diphtheria-containing vaccine should be provided during childhood and adolescence. The diphtheria booster doses should be given in combination with tetanus using the same schedule (i.e at 12–23 months of age, 4–7 years of age and 9–15 years of age, using age-appropriate vaccine formulations). Ideally, there should be at least 4 years between booster doses. Member States may update this schedule based on their country context.' + '\nDue Date: ' + ToString(\"Tetanus and diphtheria-containing vaccine booster dose 3 Due Date\") + '\nOverdue: ' + ToString(\"Tetanus and diphtheria-containing vaccine booster dose 3 Overdue\")\n  else ''"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 61
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZCommon"
      },
      {
        "url" : "name",
        "valueString" : "onOrBefore"
      },
      {
        "url" : "statement",
        "valueString" : "/**\n * @description: Gets immunizations on or before a date\n */\ndefine fluent function onOrBefore(immunizations List<Immunization>, beforeDate Date):\n  immunizations I where\n    I.occurrence.toInterval() same day or before beforeDate"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 62
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "WHOCommon"
      },
      {
        "url" : "name",
        "valueString" : "toInterval"
      },
      {
        "url" : "statement",
        "valueString" : "/*\nFrom FHIRCommon 4.1.0:\n*/\n\n/*\n@description: Normalizes a value that is a choice of timing-valued types to an equivalent interval\n@comment: Normalizes a choice type of FHIR.dateTime, FHIR.Period, FHIR.Timing, FHIR.instance, FHIR.string, FHIR.Age, or FHIR.Range types\nto an equivalent interval. This selection of choice types is a superset of the majority of choice types that are used as possible\nrepresentations for timing-valued elements in FHIR, allowing this function to be used across any resource.\n\nThe input can be provided as a dateTime, Period, Timing, instant, string, Age, or Range.\nThe intent of this function is to provide a clear and concise mechanism to treat single\nelements that have multiple possible representations as intervals so that logic doesn't have to account\nfor the variability. More complex calculations (such as medication request period or dispense period\ncalculation) need specific guidance and consideration. That guidance may make use of this function, but\nthe focus of this function is on single element calculations where the semantics are unambiguous.\nIf the input is a dateTime, the result a DateTime Interval beginning and ending on that dateTime.\nIf the input is a Period, the result is a DateTime Interval.\nIf the input is a Timing, an error is raised indicating a single interval cannot be computed from a Timing.\nIf the input is an instant, the result is a DateTime Interval beginning and ending on that instant.\nIf the input is a string, an error is raised indicating a single interval cannot be computed from a string.\nIf the input is an Age, the result is a DateTime Interval beginning when the patient was the given Age,\nand ending immediately prior to when the patient was the given Age plus one year.\nIf the input is a Range, the result is a DateTime Interval beginning when the patient was the Age given\nby the low end of the Range, and ending immediately prior to when the patient was the Age given by the\nhigh end of the Range plus one year.\n\nNOTE: Due to the\ncomplexity of determining a single interval from a Timing or String type, this function will throw a run-time exception if it is used\nwith a Timing or String.\n*/\ndefine fluent function toInterval(choice Choice<FHIR.dateTime, FHIR.Period, FHIR.Timing, FHIR.instant, FHIR.string, FHIR.Age, FHIR.Range>):\n  case\n    when choice is FHIR.dateTime then\n      Interval[FHIRHelpers.ToDateTime(choice as FHIR.dateTime), FHIRHelpers.ToDateTime(choice as FHIR.dateTime)]\n    when choice is FHIR.Period then\n      FHIRHelpers.ToInterval(choice as FHIR.Period)\n    when choice is FHIR.instant then\n      Interval[FHIRHelpers.ToDateTime(choice as FHIR.instant), FHIRHelpers.ToDateTime(choice as FHIR.instant)]\n    when choice is FHIR.Age then\n      Interval[FHIRHelpers.ToDate(Patient.birthDate) + FHIRHelpers.ToQuantity(choice as FHIR.Age),\n        FHIRHelpers.ToDate(Patient.birthDate) + FHIRHelpers.ToQuantity(choice as FHIR.Age) + 1 year)\n    when choice is FHIR.Range then\n      Interval[FHIRHelpers.ToDate(Patient.birthDate) + FHIRHelpers.ToQuantity((choice as FHIR.Range).low),\n        FHIRHelpers.ToDate(Patient.birthDate) + FHIRHelpers.ToQuantity((choice as FHIR.Range).high) + 1 year)\n    when choice is FHIR.Timing then\n      Message(null as Interval<DateTime>, true, 'NOT_IMPLEMENTED', 'Error', 'Calculation of an interval from a Timing value is not supported')\n    when choice is FHIR.string then\n      Message(null as Interval<DateTime>, true, 'NOT_IMPLEMENTED', 'Error', 'Calculation of an interval from a String value is not supported')\n    else\n      null as Interval<DateTime>\n  end"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 63
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "FHIRHelpers"
      },
      {
        "url" : "name",
        "valueString" : "ToDateTime"
      },
      {
        "url" : "statement",
        "valueString" : "define function ToDateTime(value dateTime): value.value"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 64
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "FHIRHelpers"
      },
      {
        "url" : "name",
        "valueString" : "ToInterval"
      },
      {
        "url" : "statement",
        "valueString" : "define function ToInterval(period FHIR.Period):\n    if period is null then\n        null\n    else\n        if period.\"start\" is null then\n            Interval(period.\"start\".value, period.\"end\".value]\n        else\n            Interval[period.\"start\".value, period.\"end\".value]"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 65
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "FHIRHelpers"
      },
      {
        "url" : "name",
        "valueString" : "ToDateTime"
      },
      {
        "url" : "statement",
        "valueString" : "define function ToDateTime(value instant): value.value"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 66
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "FHIRHelpers"
      },
      {
        "url" : "name",
        "valueString" : "ToDate"
      },
      {
        "url" : "statement",
        "valueString" : "define function ToDate(value date): value.value"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 67
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "FHIRHelpers"
      },
      {
        "url" : "name",
        "valueString" : "ToQuantity"
      },
      {
        "url" : "statement",
        "valueString" : "define function ToQuantity(quantity FHIR.Quantity):\n    case\n        when quantity is null then null\n        when quantity.value is null then null\n        when quantity.comparator is not null then\n            Message(null, true, 'FHIRHelpers.ToQuantity.ComparatorQuantityNotSupported', 'Error', 'FHIR Quantity value has a comparator and cannot be converted to a System.Quantity value.')\n        when quantity.system is null or quantity.system.value = 'http://unitsofmeasure.org'\n              or quantity.system.value = 'http://hl7.org/fhirpath/CodeSystem/calendar-units' then\n            System.Quantity { value: quantity.value.value, unit: ToCalendarUnit(Coalesce(quantity.code.value, quantity.unit.value, '1')) }\n        else\n            Message(null, true, 'FHIRHelpers.ToQuantity.InvalidFHIRQuantity', 'Error', 'Invalid FHIR Quantity code: ' & quantity.unit.value & ' (' & quantity.system.value & '|' & quantity.code.value & ')')\n    end"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 68
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "FHIRHelpers"
      },
      {
        "url" : "name",
        "valueString" : "ToCalendarUnit"
      },
      {
        "url" : "statement",
        "valueString" : "define function ToCalendarUnit(unit System.String):\n    case unit\n        when 'ms' then 'millisecond'\n        when 's' then 'second'\n        when 'min' then 'minute'\n        when 'h' then 'hour'\n        when 'd' then 'day'\n        when 'wk' then 'week'\n        when 'mo' then 'month'\n        when 'a' then 'year'\n        else unit\n    end"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 69
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZCommon"
      },
      {
        "url" : "name",
        "valueString" : "seriesPrimary"
      },
      {
        "url" : "statement",
        "valueString" : "/**\n * @description: Gets the doses from the primary series\n */\ndefine fluent function seriesPrimary(immunizations List<Immunization>):\n  immunizations I where\n    exists( I.protocolApplied pa where pa.series = 'Primary series' )"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 70
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "FHIRHelpers"
      },
      {
        "url" : "name",
        "valueString" : "ToString"
      },
      {
        "url" : "statement",
        "valueString" : "define function ToString(value string): value.value"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 71
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "FHIRHelpers"
      },
      {
        "url" : "name",
        "valueString" : "ToString"
      },
      {
        "url" : "statement",
        "valueString" : "define function ToString(value ImmunizationStatus): value.value"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 72
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "FHIRHelpers"
      },
      {
        "url" : "name",
        "valueString" : "ToBoolean"
      },
      {
        "url" : "statement",
        "valueString" : "define function ToBoolean(value boolean): value.value"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 73
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "FHIRHelpers"
      },
      {
        "url" : "name",
        "valueString" : "ToConcept"
      },
      {
        "url" : "statement",
        "valueString" : "define function ToConcept(concept FHIR.CodeableConcept):\n    if concept is null then\n        null\n    else\n        System.Concept {\n            codes: concept.coding C return ToCode(C),\n            display: concept.text.value\n        }"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 74
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "FHIRHelpers"
      },
      {
        "url" : "name",
        "valueString" : "ToCode"
      },
      {
        "url" : "statement",
        "valueString" : "define function ToCode(coding FHIR.Coding):\n    if coding is null then\n        null\n    else\n        System.Code {\n          code: coding.code.value,\n          system: coding.system.value,\n          version: coding.version.value,\n          display: coding.display.value\n        }"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 75
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "WHOCommon"
      },
      {
        "url" : "name",
        "valueString" : "mostRecent"
      },
      {
        "url" : "statement",
        "valueString" : "define fluent function mostRecent(immunizations List<Immunization>):\n  Last(\n    immunizations I\n      sort by start of occurrence.toInterval()\n  )"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 76
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "IMMZCommon"
      },
      {
        "url" : "name",
        "valueString" : "seriesBooster"
      },
      {
        "url" : "statement",
        "valueString" : "/**\n * @description: Gets the doses from the Booster series\n */\ndefine fluent function seriesBooster(immunizations List<Immunization>):\n  immunizations I where\n    exists( I.protocolApplied pa where pa.series = 'Booster dose' )"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 77
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    },
    {
      "extension" : [{
        "url" : "libraryName",
        "valueString" : "WHOCommon"
      },
      {
        "url" : "name",
        "valueString" : "LatestOf"
      },
      {
        "url" : "statement",
        "valueString" : "define function LatestOf(dates List<Date>):\n  Max(dates)"
      },
      {
        "url" : "displaySequence",
        "valueInteger" : 78
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
    }],
    "name" : "EffectiveDataRequirements",
    "status" : "active",
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/library-type",
        "code" : "module-definition"
      }]
    },
    "relatedArtifact" : [{
      "type" : "depends-on",
      "display" : "FHIR model information",
      "resource" : "http://fhir.org/guides/cqf/common/Library/FHIR-ModelInfo|4.0.1"
    },
    {
      "type" : "depends-on",
      "display" : "Library Encounter",
      "resource" : "http://smart.who.int/immunizations/Library/IMMZD2DTDTPEncounterElements"
    },
    {
      "type" : "depends-on",
      "display" : "Library Common",
      "resource" : "http://smart.who.int/immunizations/Library/IMMZCommon"
    },
    {
      "type" : "depends-on",
      "display" : "Library WC",
      "resource" : "http://smart.who.int/immunizations/Library/WHOCommon"
    },
    {
      "type" : "depends-on",
      "display" : "Library FHIRHelpers",
      "resource" : "http://fhir.org/guides/cqf/common/Library/FHIRHelpers|4.0.1"
    },
    {
      "type" : "depends-on",
      "display" : "Library DTPElements",
      "resource" : "http://smart.who.int/immunizations/Library/IMMZD2DTDTPElements"
    },
    {
      "type" : "depends-on",
      "display" : "Library Elements",
      "resource" : "http://smart.who.int/immunizations/Library/IMMZElements"
    },
    {
      "type" : "depends-on",
      "display" : "Library Concepts",
      "resource" : "http://smart.who.int/immunizations/Library/IMMZConcepts"
    },
    {
      "type" : "depends-on",
      "display" : "Library Encounter",
      "resource" : "http://smart.who.int/immunizations/Library/IMMZEncounterElements"
    },
    {
      "type" : "depends-on",
      "display" : "Value set DTP-containing vaccines",
      "resource" : "http://smart.who.int/immunizations/ValueSet/IMMZ.Z.DE24"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Pertussis-containing vaccines",
      "resource" : "http://smart.who.int/immunizations/ValueSet/IMMZ.Z.DE12"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Tetanus and diphtheria-containing vaccines",
      "resource" : "http://smart.who.int/immunizations/ValueSet/IMMZ.Z.DE28"
    }],
    "parameter" : [{
      "name" : "Today",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "type" : "date"
    },
    {
      "name" : "DTP dose 3 Create",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "string"
    },
    {
      "name" : "DTP dose 3",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "boolean"
    },
    {
      "name" : "DTP dose 1 Create",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "string"
    },
    {
      "name" : "Pertussis-containing vaccine booster dose Create",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "string"
    },
    {
      "name" : "DTP dose 2 Create",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "string"
    },
    {
      "name" : "Pertussis-containing vaccine booster dose",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "boolean"
    },
    {
      "name" : "Tetanus and diphtheria-containing vaccine booster dose 2 Create",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "string"
    },
    {
      "name" : "Tetanus and diphtheria-containing vaccine booster dose 1",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "boolean"
    },
    {
      "name" : "Tetanus and diphtheria-containing vaccine booster dose 1 Create",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "string"
    },
    {
      "name" : "Tetanus and diphtheria-containing vaccine booster dose 3 Create",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "string"
    },
    {
      "name" : "Tetanus and diphtheria-containing vaccine booster dose 3",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "boolean"
    },
    {
      "name" : "Tetanus and diphtheria-containing vaccine booster dose 2",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "boolean"
    },
    {
      "name" : "DTP dose 1",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "boolean"
    },
    {
      "name" : "DTP dose 2",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "boolean"
    }],
    "dataRequirement" : [{
      "type" : "Patient",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Patient"],
      "mustSupport" : ["birthDate"]
    },
    {
      "type" : "Immunization",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Immunization"],
      "mustSupport" : ["status", "isSubpotent", "occurrence", "protocolApplied"],
      "codeFilter" : [{
        "path" : "status",
        "code" : [{
          "code" : "completed"
        }]
      }]
    },
    {
      "type" : "Immunization",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Immunization"],
      "mustSupport" : ["occurrence", "protocolApplied"]
    },
    {
      "type" : "Immunization",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Immunization"],
      "mustSupport" : ["status",
      "isSubpotent",
      "vaccineCode",
      "occurrence",
      "protocolApplied"],
      "codeFilter" : [{
        "path" : "status",
        "code" : [{
          "code" : "completed"
        }]
      },
      {
        "path" : "vaccineCode",
        "valueSet" : "http://smart.who.int/immunizations/ValueSet/IMMZ.Z.DE24"
      }]
    },
    {
      "type" : "Immunization",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Immunization"],
      "mustSupport" : ["status",
      "isSubpotent",
      "vaccineCode",
      "occurrence",
      "protocolApplied"],
      "codeFilter" : [{
        "path" : "status",
        "code" : [{
          "code" : "completed"
        }]
      },
      {
        "path" : "vaccineCode",
        "valueSet" : "http://smart.who.int/immunizations/ValueSet/IMMZ.Z.DE12"
      }]
    },
    {
      "type" : "Immunization",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Immunization"],
      "mustSupport" : ["status",
      "isSubpotent",
      "vaccineCode",
      "occurrence",
      "protocolApplied"],
      "codeFilter" : [{
        "path" : "status",
        "code" : [{
          "code" : "completed"
        }]
      },
      {
        "path" : "vaccineCode",
        "valueSet" : "http://smart.who.int/immunizations/ValueSet/IMMZ.Z.DE28"
      }]
    }]
  }],
  "extension" : [{
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-effectiveDataRequirements",
    "valueCanonical" : "#effective-data-requirements"
  }],
  "url" : "http://smart.who.int/immunizations/PlanDefinition/IMMZD18SDTPOnTimeStart",
  "version" : "1.0.0",
  "name" : "IMMZD18SDTPOnTimeStart",
  "title" : "IMMZ.D18.S.DTP.On-time start schedule",
  "type" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/plan-definition-type",
      "code" : "eca-rule"
    }]
  },
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-04-09T13:50:16+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "IMMZ.D18.S.DTP.On-time start schedule\nDiphtheria–tetanus–pertussis (DTP) vaccination schedule, on-time start (at ≤ 12 months of age)",
  "relatedArtifact" : [{
    "type" : "citation",
    "citation" : "WHO recommendations for routine immunization - summary tables (January 2025)"
  }],
  "library" : ["http://smart.who.int/immunizations/Library/IMMZD18SDTPOnTimeStartLogic"],
  "action" : [{
    "title" : "DTP dose 1",
    "description" : "Provision of DTP dose 1\nTrigger event: Child's birth\nTrigger pseudo: \nTrigger date: \"Date of birth\"\nCreate condition: DTP dose 1 should be provided if the client is older than 6 weeks of age.",
    "condition" : [{
      "kind" : "applicability",
      "expression" : {
        "description" : "DTP dose 1",
        "language" : "text/cql-identifier",
        "expression" : "DTP dose 1"
      }
    }],
    "definitionCanonical" : "http://smart.who.int/immunizations/ActivityDefinition/IMMZD2DTCR",
    "dynamicValue" : [{
      "path" : "status",
      "expression" : {
        "language" : "text/cql-expression",
        "expression" : "'active'"
      }
    },
    {
      "path" : "payload.contentString",
      "expression" : {
        "language" : "text/cql-identifier",
        "expression" : "DTP dose 1 Create"
      }
    },
    {
      "path" : "category.coding",
      "expression" : {
        "description" : "Category of communication",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://terminology.hl7.org/CodeSystem/communication-category', code: 'alert' }"
      }
    },
    {
      "path" : "priority",
      "expression" : {
        "description" : "Alert priority",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://hl7.org/fhir/request-priority', code: 'routine' }"
      }
    }]
  },
  {
    "title" : "DTP dose 2",
    "description" : "Provision of DTP dose 2\nTrigger event: First DTP dose from the primary series was administered\nTrigger pseudo: Count of vaccines administered (where \"Vaccine type\" = \"DTP-containing vaccines\" and \"Type of dose\" = \"Primary series\") = 1\nTrigger date: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"DTP-containing vaccines\")\nCreate condition: DTP dose 2 should be provided if the client was given the previous DTP dose more than 4 weeks ago.",
    "condition" : [{
      "kind" : "applicability",
      "expression" : {
        "description" : "DTP dose 2",
        "language" : "text/cql-identifier",
        "expression" : "DTP dose 2"
      }
    }],
    "definitionCanonical" : "http://smart.who.int/immunizations/ActivityDefinition/IMMZD2DTCR",
    "dynamicValue" : [{
      "path" : "status",
      "expression" : {
        "language" : "text/cql-expression",
        "expression" : "'active'"
      }
    },
    {
      "path" : "payload.contentString",
      "expression" : {
        "language" : "text/cql-identifier",
        "expression" : "DTP dose 2 Create"
      }
    },
    {
      "path" : "category.coding",
      "expression" : {
        "description" : "Category of communication",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://terminology.hl7.org/CodeSystem/communication-category', code: 'alert' }"
      }
    },
    {
      "path" : "priority",
      "expression" : {
        "description" : "Alert priority",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://hl7.org/fhir/request-priority', code: 'routine' }"
      }
    }]
  },
  {
    "title" : "DTP dose 3",
    "description" : "Provision of DTP dose 3\nTrigger event: Second DTP dose from the primary series was administered\nTrigger pseudo: Count of vaccines administered (where \"Vaccine type\" = \"DTP-containing vaccines\" and \"Type of dose\" = \"Primary series\" ) = 2\nTrigger date: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"DTP-containing vaccines\")\nCreate condition: DTP dose 3 should be provided if the client received the previous dose more than 4 weeks ago.",
    "condition" : [{
      "kind" : "applicability",
      "expression" : {
        "description" : "DTP dose 3",
        "language" : "text/cql-identifier",
        "expression" : "DTP dose 3"
      }
    }],
    "definitionCanonical" : "http://smart.who.int/immunizations/ActivityDefinition/IMMZD2DTCR",
    "dynamicValue" : [{
      "path" : "status",
      "expression" : {
        "language" : "text/cql-expression",
        "expression" : "'active'"
      }
    },
    {
      "path" : "payload.contentString",
      "expression" : {
        "language" : "text/cql-identifier",
        "expression" : "DTP dose 3 Create"
      }
    },
    {
      "path" : "category.coding",
      "expression" : {
        "description" : "Category of communication",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://terminology.hl7.org/CodeSystem/communication-category', code: 'alert' }"
      }
    },
    {
      "path" : "priority",
      "expression" : {
        "description" : "Alert priority",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://hl7.org/fhir/request-priority', code: 'routine' }"
      }
    }]
  },
  {
    "title" : "Tetanus and diphtheria-containing vaccine booster dose 1",
    "description" : "Provision of tetanus and diphtheria booster dose 1\nTrigger event: The primary DTP series has been completed\nTrigger pseudo: \"Completed the primary vaccination series\" = TRUE (where \"Vaccine type\" = \"DTP-containing vaccines\")\nTrigger date: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"DTP-containing vaccines\")\nCreate condition: Three booster doses of diphtheria-containing vaccine should be provided during childhood and adolescence. The diphtheria booster doses should be given in combination with tetanus using the same schedule (i.e at 12–23 months of age, 4–7 years of age and 9–15 years of age, using age-appropriate vaccine formulations). Ideally, there should be at least 4 years between booster doses. Member States may update this schedule based on their country context.",
    "condition" : [{
      "kind" : "applicability",
      "expression" : {
        "description" : "Tetanus and diphtheria-containing vaccine booster dose 1",
        "language" : "text/cql-identifier",
        "expression" : "Tetanus and diphtheria-containing vaccine booster dose 1"
      }
    }],
    "definitionCanonical" : "http://smart.who.int/immunizations/ActivityDefinition/IMMZD2DTCR",
    "dynamicValue" : [{
      "path" : "status",
      "expression" : {
        "language" : "text/cql-expression",
        "expression" : "'active'"
      }
    },
    {
      "path" : "payload.contentString",
      "expression" : {
        "language" : "text/cql-identifier",
        "expression" : "Tetanus and diphtheria-containing vaccine booster dose 1 Create"
      }
    },
    {
      "path" : "category.coding",
      "expression" : {
        "description" : "Category of communication",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://terminology.hl7.org/CodeSystem/communication-category', code: 'alert' }"
      }
    },
    {
      "path" : "priority",
      "expression" : {
        "description" : "Alert priority",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://hl7.org/fhir/request-priority', code: 'routine' }"
      }
    }]
  },
  {
    "title" : "Tetanus and diphtheria-containing vaccine booster dose 2",
    "description" : "Provision of tetanus and diphtheria booster dose 2\nTrigger event: First tetanus and diphtheria booster dose was administered\nTrigger pseudo: Count of vaccines administered (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\" and \"Type of dose\" = \"Booster dose\") = 1\nTrigger date: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\")\nCreate condition: Three booster doses of diphtheria-containing vaccine should be provided during childhood and adolescence. The diphtheria booster doses should be given in combination with tetanus using the same schedule (i.e at 12–23 months of age, 4–7 years of age and 9–15 years of age, using age-appropriate vaccine formulations). Ideally, there should be at least 4 years between booster doses. Member States may update this schedule based on their country context.",
    "condition" : [{
      "kind" : "applicability",
      "expression" : {
        "description" : "Tetanus and diphtheria-containing vaccine booster dose 2",
        "language" : "text/cql-identifier",
        "expression" : "Tetanus and diphtheria-containing vaccine booster dose 2"
      }
    }],
    "definitionCanonical" : "http://smart.who.int/immunizations/ActivityDefinition/IMMZD2DTCR",
    "dynamicValue" : [{
      "path" : "status",
      "expression" : {
        "language" : "text/cql-expression",
        "expression" : "'active'"
      }
    },
    {
      "path" : "payload.contentString",
      "expression" : {
        "language" : "text/cql-identifier",
        "expression" : "Tetanus and diphtheria-containing vaccine booster dose 2 Create"
      }
    },
    {
      "path" : "category.coding",
      "expression" : {
        "description" : "Category of communication",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://terminology.hl7.org/CodeSystem/communication-category', code: 'alert' }"
      }
    },
    {
      "path" : "priority",
      "expression" : {
        "description" : "Alert priority",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://hl7.org/fhir/request-priority', code: 'routine' }"
      }
    }]
  },
  {
    "title" : "Tetanus and diphtheria-containing vaccine booster dose 3",
    "description" : "Provision of tetanus and diphtheria booster dose 3\nTrigger event: Second tetanus and diphtheria booster dose was administered\nTrigger pseudo: Count of vaccines administered (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\" and \"Type of dose\" = \"Booster dose\") = 2\nTrigger date: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"Tetanus and diphtheria-containing vaccines\")\nCreate condition: Three booster doses of diphtheria-containing vaccine should be provided during childhood and adolescence. The diphtheria booster doses should be given in combination with tetanus using the same schedule (i.e at 12–23 months of age, 4–7 years of age and 9–15 years of age, using age-appropriate vaccine formulations). Ideally, there should be at least 4 years between booster doses. Member States may update this schedule based on their country context.",
    "condition" : [{
      "kind" : "applicability",
      "expression" : {
        "description" : "Tetanus and diphtheria-containing vaccine booster dose 3",
        "language" : "text/cql-identifier",
        "expression" : "Tetanus and diphtheria-containing vaccine booster dose 3"
      }
    }],
    "definitionCanonical" : "http://smart.who.int/immunizations/ActivityDefinition/IMMZD2DTCR",
    "dynamicValue" : [{
      "path" : "status",
      "expression" : {
        "language" : "text/cql-expression",
        "expression" : "'active'"
      }
    },
    {
      "path" : "payload.contentString",
      "expression" : {
        "language" : "text/cql-identifier",
        "expression" : "Tetanus and diphtheria-containing vaccine booster dose 3 Create"
      }
    },
    {
      "path" : "category.coding",
      "expression" : {
        "description" : "Category of communication",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://terminology.hl7.org/CodeSystem/communication-category', code: 'alert' }"
      }
    },
    {
      "path" : "priority",
      "expression" : {
        "description" : "Alert priority",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://hl7.org/fhir/request-priority', code: 'routine' }"
      }
    }]
  },
  {
    "title" : "Pertussis-containing vaccine booster dose",
    "description" : "Provision of the pertussis-containing vaccine booster dose\nTrigger event: The primary DTP series has been completed and client's age is between 1 and 6 years\nTrigger pseudo: \"Completed the primary vaccination series\" = TRUE (where \"Vaccine type\" = \"DTP-containing vaccines\") AND 1 year ≤ Today's date − \"Date of birth\" ≤ 6 years\nTrigger date: Latest \"Date and time of vaccination\" (where \"Vaccine type\" = \"DTP-containing vaccines\")\nCreate condition: A booster dose is recommended for children aged 1–6 years, preferably during the second year of life (≥6 months after last primary dose).",
    "condition" : [{
      "kind" : "applicability",
      "expression" : {
        "description" : "Pertussis-containing vaccine booster dose",
        "language" : "text/cql-identifier",
        "expression" : "Pertussis-containing vaccine booster dose"
      }
    }],
    "definitionCanonical" : "http://smart.who.int/immunizations/ActivityDefinition/IMMZD2DTCR",
    "dynamicValue" : [{
      "path" : "status",
      "expression" : {
        "language" : "text/cql-expression",
        "expression" : "'active'"
      }
    },
    {
      "path" : "payload.contentString",
      "expression" : {
        "language" : "text/cql-identifier",
        "expression" : "Pertussis-containing vaccine booster dose Create"
      }
    },
    {
      "path" : "category.coding",
      "expression" : {
        "description" : "Category of communication",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://terminology.hl7.org/CodeSystem/communication-category', code: 'alert' }"
      }
    },
    {
      "path" : "priority",
      "expression" : {
        "description" : "Alert priority",
        "language" : "text/cql-expression",
        "expression" : "Code { system: 'http://hl7.org/fhir/request-priority', code: 'routine' }"
      }
    }]
  }]
}

```
