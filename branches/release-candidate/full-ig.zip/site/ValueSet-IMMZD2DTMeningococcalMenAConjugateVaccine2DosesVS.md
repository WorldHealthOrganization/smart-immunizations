# IMMZD2DTMeningococcalMenAConjugateVaccine2Doses ValueSet for Decision Table - WHO Immunization Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* **IMMZD2DTMeningococcalMenAConjugateVaccine2Doses ValueSet for Decision Table**

## ValueSet: IMMZD2DTMeningococcalMenAConjugateVaccine2Doses ValueSet for Decision Table 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/immunizations/ValueSet/IMMZD2DTMeningococcalMenAConjugateVaccine2DosesVS | *Version*:1.0.0 |
| Active as of 2026-04-09 | *Computable Name*:IMMZD2DTMeningococcalMenAConjugateVaccine2DosesVS |

 
ValueSet IMMZD2DTMeningococcalMenAConjugateVaccine2Doses for IMMZ.D2.DT.Meningococcal.MenA conjugate vaccine 2 doses. Business rule: Determine if the client is due for a meningococcal vaccination according to the national immunization schedule Trigger: IMMZ.D2 Determine required vaccination(s) if any Table: MenA conjugate vaccine, 2-dose schedule (specific context where there is a compelling reason to vaccinate infants aged under 9 months) 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

## API Information

##### IMMZD2DTMeningococcalMenAConjugateVaccine2Doses ValueSet for Decision Table Schema API

JSON Schema for IMMZD2DTMeningococcalMenAConjugateVaccine2Doses ValueSet for Decision Table ValueSet codes. Generated from FHIR expansions using IRI format.

**Version:** 1.0.0

## Endpoints

### GET /ValueSet-IMMZD2DTMeningococcalMenAConjugateVaccine2DosesVS.schema.json

#### JSON Schema definition for the enumeration ValueSet-IMMZD2DTMeningococcalMenAConjugateVaccine2DosesVS

This endpoint serves the JSON Schema definition for the enumeration ValueSet-IMMZD2DTMeningococcalMenAConjugateVaccine2DosesVS.

## Schema Definition

### ValueSet-IMMZD2DTMeningococcalMenAConjugateVaccine2DosesVS

**Description:** JSON Schema for IMMZD2DTMeningococcalMenAConjugateVaccine2Doses ValueSet for Decision Table ValueSet codes. Generated from FHIR expansions using IRI format.

**Type:** string

**This documentation is automatically generated from the OpenAPI specification.**



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "IMMZD2DTMeningococcalMenAConjugateVaccine2DosesVS",
  "url" : "http://smart.who.int/immunizations/ValueSet/IMMZD2DTMeningococcalMenAConjugateVaccine2DosesVS",
  "version" : "1.0.0",
  "name" : "IMMZD2DTMeningococcalMenAConjugateVaccine2DosesVS",
  "title" : "IMMZD2DTMeningococcalMenAConjugateVaccine2Doses ValueSet for Decision Table",
  "status" : "active",
  "date" : "2026-04-09T13:50:16+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "ValueSet IMMZD2DTMeningococcalMenAConjugateVaccine2Doses for IMMZ.D2.DT.Meningococcal.MenA conjugate vaccine 2 doses.\nBusiness rule: Determine if the client is due for a meningococcal vaccination according to the national immunization schedule\nTrigger: IMMZ.D2 Determine required vaccination(s) if any\nTable: MenA conjugate vaccine, 2-dose schedule (specific context where there is a compelling reason to vaccinate infants aged under 9 months)",
  "compose" : {
    "include" : [{
      "system" : "http://smart.who.int/immunizations/CodeSystem/IMMZDAK",
      "concept" : [{
        "code" : "Client's age is less than 3 months-41",
        "display" : "Client's age is less than 3 months"
      },
      {
        "code" : "Client is not due for meningococcal vaccination-48",
        "display" : "Client is not due for meningococcal vaccination"
      },
      {
        "code" : "No meningococcal primary series dose was administered-122",
        "display" : "No meningococcal primary series dose was administered"
      },
      {
        "code" : "Client's age is more than or equal to 3 months-41",
        "display" : "Client's age is more than or equal to 3 months"
      },
      {
        "code" : "Client is due for meningococcal vaccination-44",
        "display" : "Client is due for meningococcal vaccination"
      },
      {
        "code" : "One meningococcal primary series dose was administered-122",
        "display" : "One meningococcal primary series dose was administered"
      },
      {
        "code" : "The latest meningococcal dose was administered less than 8 weeks ago-105",
        "display" : "The latest meningococcal dose was administered less than 8 weeks ago"
      },
      {
        "code" : "The latest meningococcal dose was administered more than 8 weeks ago-105",
        "display" : "The latest meningococcal dose was administered more than 8 weeks ago"
      },
      {
        "code" : "Two meningococcal primary series doses were administered-122",
        "display" : "Two meningococcal primary series doses were administered"
      },
      {
        "code" : "Meningococcal immunization schedule is complete-149",
        "display" : "Meningococcal immunization schedule is complete"
      }]
    }]
  }
}

```
