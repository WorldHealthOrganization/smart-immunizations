# Home - WHO Immunization Implementation Guide v0.2.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/immunizations/ImplementationGuide/smart.who.int.immunizations | *Version*:0.2.0 |
| Draft as of 2024-12-06 | *Computable Name*:Immunizations |

This WHO Implementation Guide for Immunizations details how to use Health Level 7 (HL7) Fast Healthcare Interoperability Resources (FHIR) for consistent digital representation of Immunization services.

 This implementation guide and set of artifacts are still undergoing development. 

 Content is for demonstration purposes only. 

### Summary

This implementation guide includes a machine-readable representation of WHO guidelines for Immunizations, as documented in the WHO Digital Adaptation Kit for Immunizations (link forthcoming) and explicitly encodes computer-interoperable logic, including data models, terminologies, and logic expressions, in a computable language to support implementation of Immunization use cases by WHO Member States.

The guide is part of the [WHO SMART Guidelines approach](https://www.who.int/teams/digital-health-and-innovation/smart-guidelines) to support countries to integrate WHO global health and data recommendations into digital systems accurately and consistently. It defines a series of FHIR Resources, Profiles, Extensions, and Terminology based on the [WHO Digital Adaptation Kit for Immunizations](https://www.who.int/publications/i/item/9789240099456).

Supporting guidance, recommendations, resources, and standards are included in the [References](references.md) and [Dependencies](dependencies.md).

### About this implementation guide

This implementation guide is broken into the following levels of [knowledge representation](https://hl7.org/fhir/uv/cpg/documentation-approach-06-01-levels-of-knowledge-representation.html):

* [Home](index.md) - contains references to the guidance, guidelines, policies and recommendations underpinning this implementation guide.
* [Business Requirements](business-requirements.md) - contains the requirements for this implementation guide including the definition of key concepts, use cases, and a data dictionary.
* [Data Models and Exchange](data-models-and-exchange.md) - contains the data models and data exchange protocols with actors and transactions defined.
* [Deployment Guidance ](deployment.md) - contains relevant technical specifications and guidance, testing resources, reference implementation materials, and supporting guidance for adaptation to local contexts.

This guide is prepared to facilitate digital implementation of WHO Immunization guidelines by providing FHIR-based computable representations of and implementation guidance for using the key components of the WHO Digital adaptation kit (DAK) for immunizations:

* Health Interventions & Recommendations
* Generic Personas
* User Scenarios
* Business Processes & Workflows
* Core Data Elements
* Decision Support Logic
* Indicators & Monitoring
* Functional & Non-functional Requirements

This guide is a companion to the Digital Adaptation Kit (DAK) and should be used side-by-side with it. Implementers are strongly encouraged to make use of the Digital Adaptation Kit. The focus of this guide is on the explanation and use of the computable artifacts.

This guide assumes use of the following resources:

* [IPS Patient](http://hl7.org/fhir/uv/ips/StructureDefinition/Patient-uv-ips)
* [CPG ActivityDefinitions](https://hl7.org/fhir/uv/cpg/artifacts.html#activitydefinition-index)
* For a complete listing of the artifacts defined in this implementation guide, refer to the [Artifact Index](artifacts.md).
* A complete offline copy of this implementation guide can be found on the [Downloads](downloads.md) page.
* This Implementation Guide makes use of [Clinical Quality Language](https://cql.hl7.org/) for the decision support artifacts including the PlanDefinitions and Measures. They are used to express how a calculation should occur and can be used with a CQL engine in order to process the decision or indicator directly from the applicable FHIR resources. Links to this specification, the FHIR Clinical Practice Guidelines Speciciation, and other helpful resources can be found in the Support dropdown.

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

This publication includes IP covered under the following statements.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.1.0/CodeSystem-ISO3166Part1.html): [IMMZCountryOfVaccination](StructureDefinition-IMMZCountryOfVaccination.md), [IMMZ_D13_Update_client_record](StructureDefinition-IMMZD13.md)... Show 4 more, [Questionnaire/QIMMZD13](Questionnaire-QIMMZD13.md), [QuestionnaireResponse/Example.IMMZ.D13.QuestionnaireResponse.BCG](QuestionnaireResponse-Example.IMMZ.D13.QuestionnaireResponse.BCG.md), [QuestionnaireResponse/Example.IMMZ.D13.QuestionnaireResponse.Measles](QuestionnaireResponse-Example.IMMZ.D13.QuestionnaireResponse.Measles.md) and [QuestionnaireResponse/Example.IMMZ.D13.QuestionnaireResponse.Measles.2](QuestionnaireResponse-Example.IMMZ.D13.QuestionnaireResponse.Measles.2.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.1.0/CodeSystem-v3-ucum.html): [QuestionnaireResponse/Example.IMMZ.D13.QuestionnaireResponse.BCG](QuestionnaireResponse-Example.IMMZ.D13.QuestionnaireResponse.BCG.md) and [QuestionnaireResponse/Example.IMMZ.D13.QuestionnaireResponse.Measles](QuestionnaireResponse-Example.IMMZ.D13.QuestionnaireResponse.Measles.md)


* The WHO grants a license for "commercial and non-commercial use" of ICD-11CC BY-ND 3.0 IGODetailed information can be found here: [[https://icd.who.int/en/docs/icd11-license.pdf](https://icd.who.int/en/docs/icd11-license.pdf)](https://icd.who.int/en/docs/icd11-license.pdf) Contact licensing@who.int to obtain further information.

* [International Classification of Diseases, 11th Revision Mortality and Morbidity Statistics (MMS)](http://terminology.hl7.org/6.1.0/CodeSystem-ICD11MMS.html): [IMMZ_D13_Update_client_record](StructureDefinition-IMMZD13.md), [IMMZ_D17_Report_AEFI](StructureDefinition-IMMZD17.md)... Show 40 more, [IMMZ_D1_Capture_or_update_client_history](StructureDefinition-IMMZD1.md), [IMMZ_D7_Counsel_client](StructureDefinition-IMMZD7.md), [IMMZ_Z_DE1](ValueSet-IMMZ.Z.DE1.md), [IMMZ_Z_DE10](ValueSet-IMMZ.Z.DE10.md), [IMMZ_Z_DE11](ValueSet-IMMZ.Z.DE11.md), [IMMZ_Z_DE12](ValueSet-IMMZ.Z.DE12.md), [IMMZ_Z_DE13](ValueSet-IMMZ.Z.DE13.md), [IMMZ_Z_DE14](ValueSet-IMMZ.Z.DE14.md), [IMMZ_Z_DE15](ValueSet-IMMZ.Z.DE15.md), [IMMZ_Z_DE16](ValueSet-IMMZ.Z.DE16.md), [IMMZ_Z_DE17](ValueSet-IMMZ.Z.DE17.md), [IMMZ_Z_DE18](ValueSet-IMMZ.Z.DE18.md), [IMMZ_Z_DE19](ValueSet-IMMZ.Z.DE19.md), [IMMZ_Z_DE2](ValueSet-IMMZ.Z.DE2.md), [IMMZ_Z_DE20](ValueSet-IMMZ.Z.DE20.md), [IMMZ_Z_DE21](ValueSet-IMMZ.Z.DE21.md), [IMMZ_Z_DE22](ValueSet-IMMZ.Z.DE22.md), [IMMZ_Z_DE23](ValueSet-IMMZ.Z.DE23.md), [IMMZ_Z_DE24](ValueSet-IMMZ.Z.DE24.md), [IMMZ_Z_DE25](ValueSet-IMMZ.Z.DE25.md), [IMMZ_Z_DE26](ValueSet-IMMZ.Z.DE26.md), [IMMZ_Z_DE28](ValueSet-IMMZ.Z.DE28.md), [IMMZ_Z_DE29](ValueSet-IMMZ.Z.DE29.md), [IMMZ_Z_DE3](ValueSet-IMMZ.Z.DE3.md), [IMMZ_Z_DE30](ValueSet-IMMZ.Z.DE30.md), [IMMZ_Z_DE31](ValueSet-IMMZ.Z.DE31.md), [IMMZ_Z_DE32](ValueSet-IMMZ.Z.DE32.md), [IMMZ_Z_DE33](ValueSet-IMMZ.Z.DE33.md), [IMMZ_Z_DE34](ValueSet-IMMZ.Z.DE34.md), [IMMZ_Z_DE4](ValueSet-IMMZ.Z.DE4.md), [IMMZ_Z_DE5](ValueSet-IMMZ.Z.DE5.md), [IMMZ_Z_DE6](ValueSet-IMMZ.Z.DE6.md), [IMMZ_Z_DE7](ValueSet-IMMZ.Z.DE7.md), [IMMZ_Z_DE8](ValueSet-IMMZ.Z.DE8.md), [IMMZ_Z_DE9](ValueSet-IMMZ.Z.DE9.md), [IMMZ_Z_LiveAttenuated](ValueSet-IMMZ.Z.LiveAttenuated.md), [Questionnaire/QIMMZD1](Questionnaire-QIMMZD1.md), [Questionnaire/QIMMZD13](Questionnaire-QIMMZD13.md), [Questionnaire/QIMMZD17](Questionnaire-QIMMZD17.md) and [Questionnaire/QIMMZD7](Questionnaire-QIMMZD7.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.1.0/CodeSystem-v3-loinc.html): [IMMZD18SDTPPregnancyStartingWith3Doses](PlanDefinition-IMMZD18SDTPPregnancyStartingWith3Doses.md), [IMMZD18SDTPPregnancyStartingWith4Doses](PlanDefinition-IMMZD18SDTPPregnancyStartingWith4Doses.md)... Show 33 more, [IMMZD2DTDTPPregnancy](PlanDefinition-IMMZD2DTDTPPregnancy.md), [IMMZD2DTDTPPregnancyStartingWith3Doses](PlanDefinition-IMMZD2DTDTPPregnancyStartingWith3Doses.md), [IMMZD2DTDTPPregnancyStartingWith4Doses](PlanDefinition-IMMZD2DTDTPPregnancyStartingWith4Doses.md), [IMMZD5DTBCGContraindications](PlanDefinition-IMMZD5DTBCGContraindications.md), [IMMZD5DTDengueContraindications](PlanDefinition-IMMZD5DTDengueContraindications.md), [IMMZD5DTHPVContraindications](PlanDefinition-IMMZD5DTHPVContraindications.md), [IMMZD5DTHepatitisAContraindications](PlanDefinition-IMMZD5DTHepatitisAContraindications.md), [IMMZD5DTJEContraindications](PlanDefinition-IMMZD5DTJEContraindications.md), [IMMZD5DTMeaslesContraindications](PlanDefinition-IMMZD5DTMeaslesContraindications.md), [IMMZD5DTMumpsContraindications](PlanDefinition-IMMZD5DTMumpsContraindications.md), [IMMZD5DTRubellaContraindications](PlanDefinition-IMMZD5DTRubellaContraindications.md), [IMMZD5DTTBEContraindications](PlanDefinition-IMMZD5DTTBEContraindications.md), [IMMZD5DTTyphoidContraindications](PlanDefinition-IMMZD5DTTyphoidContraindications.md), [IMMZD5DTVaricellaContraindications](PlanDefinition-IMMZD5DTVaricellaContraindications.md), [IMMZD5DTYellowFeverContraindications](PlanDefinition-IMMZD5DTYellowFeverContraindications.md), [IMMZ_C4_Create_client_record](StructureDefinition-IMMZC4.md), [IMMZ_D13_Update_client_record](StructureDefinition-IMMZD13.md), [IMMZ_D17_Report_AEFI](StructureDefinition-IMMZD17.md), [IMMZ_D18_Determine_time_for_next_visit](StructureDefinition-IMMZD18.md), [IMMZ_D1_Capture_or_update_client_history](StructureDefinition-IMMZD1.md), [IMMZ_Z_DE11](ValueSet-IMMZ.Z.DE11.md), [IMMZ_Z_DE17](ValueSet-IMMZ.Z.DE17.md), [IMMZ_Z_DE3](ValueSet-IMMZ.Z.DE3.md), [IMMZ_Z_DE32](ValueSet-IMMZ.Z.DE32.md), [IMMZ_Z_DE4](ValueSet-IMMZ.Z.DE4.md), [IMMZ_Z_DE6](ValueSet-IMMZ.Z.DE6.md), [IMMZ_Z_DE9](ValueSet-IMMZ.Z.DE9.md), [Questionnaire/QIMMZC4](Questionnaire-QIMMZC4.md), [Questionnaire/QIMMZD1](Questionnaire-QIMMZD1.md), [Questionnaire/QIMMZD13](Questionnaire-QIMMZD13.md), [Questionnaire/QIMMZD17](Questionnaire-QIMMZD17.md), [Questionnaire/QIMMZD18](Questionnaire-QIMMZD18.md) and [WHOElements](Library-WHOElements.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [IMMZ_C4_Create_client_record](StructureDefinition-IMMZC4.md), [IMMZ_D13_Update_client_record](StructureDefinition-IMMZD13.md)... Show 32 more, [IMMZ_D17_Report_AEFI](StructureDefinition-IMMZD17.md), [IMMZ_D18_Determine_time_for_next_visit](StructureDefinition-IMMZD18.md), [IMMZ_D1_Capture_or_update_client_history](StructureDefinition-IMMZD1.md), [IMMZ_Z_DE1](ValueSet-IMMZ.Z.DE1.md), [IMMZ_Z_DE10](ValueSet-IMMZ.Z.DE10.md), [IMMZ_Z_DE11](ValueSet-IMMZ.Z.DE11.md), [IMMZ_Z_DE12](ValueSet-IMMZ.Z.DE12.md), [IMMZ_Z_DE13](ValueSet-IMMZ.Z.DE13.md), [IMMZ_Z_DE14](ValueSet-IMMZ.Z.DE14.md), [IMMZ_Z_DE15](ValueSet-IMMZ.Z.DE15.md), [IMMZ_Z_DE16](ValueSet-IMMZ.Z.DE16.md), [IMMZ_Z_DE17](ValueSet-IMMZ.Z.DE17.md), [IMMZ_Z_DE18](ValueSet-IMMZ.Z.DE18.md), [IMMZ_Z_DE2](ValueSet-IMMZ.Z.DE2.md), [IMMZ_Z_DE20](ValueSet-IMMZ.Z.DE20.md), [IMMZ_Z_DE22](ValueSet-IMMZ.Z.DE22.md), [IMMZ_Z_DE23](ValueSet-IMMZ.Z.DE23.md), [IMMZ_Z_DE24](ValueSet-IMMZ.Z.DE24.md), [IMMZ_Z_DE26](ValueSet-IMMZ.Z.DE26.md), [IMMZ_Z_DE3](ValueSet-IMMZ.Z.DE3.md), [IMMZ_Z_DE4](ValueSet-IMMZ.Z.DE4.md), [IMMZ_Z_DE5](ValueSet-IMMZ.Z.DE5.md), [IMMZ_Z_DE6](ValueSet-IMMZ.Z.DE6.md), [IMMZ_Z_DE7](ValueSet-IMMZ.Z.DE7.md), [IMMZ_Z_DE8](ValueSet-IMMZ.Z.DE8.md), [IMMZ_Z_DE9](ValueSet-IMMZ.Z.DE9.md), [IMMZ_Z_LiveAttenuated](ValueSet-IMMZ.Z.LiveAttenuated.md), [Questionnaire/QIMMZC4](Questionnaire-QIMMZC4.md), [Questionnaire/QIMMZD1](Questionnaire-QIMMZD1.md), [Questionnaire/QIMMZD13](Questionnaire-QIMMZD13.md), [Questionnaire/QIMMZD17](Questionnaire-QIMMZD17.md) and [Questionnaire/QIMMZD18](Questionnaire-QIMMZD18.md)


