# Library - WHO Immunization Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* [**IMMZ.D18.S.JE.Inactivated Vero cell-derived vaccination schedule**](PlanDefinition-IMMZD18SJEInactivatedVeroCellDerivedVaccine.md)
* **Library**

## Library: Library 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/immunizations/PlanDefinition/IMMZD18SJEInactivatedVeroCellDerivedVaccine#effective-data-requirements | *Version*:1.0.0 |
| Draft | *Computable Name*:EffectiveDataRequirements |

