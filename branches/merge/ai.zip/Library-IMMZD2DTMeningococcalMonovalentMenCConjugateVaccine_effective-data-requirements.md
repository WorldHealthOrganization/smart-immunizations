# Library - WHO Immunization Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* [**IMMZ.D2.DT.Meningococcal.Monovalent MenC conjugate vaccine**](PlanDefinition-IMMZD2DTMeningococcalMonovalentMenCConjugateVaccine.md)
* **Library**

## Library: Library 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/immunizations/PlanDefinition/IMMZD2DTMeningococcalMonovalentMenCConjugateVaccine#effective-data-requirements | *Version*:1.0.0 |
| Draft | *Computable Name*:EffectiveDataRequirements |

