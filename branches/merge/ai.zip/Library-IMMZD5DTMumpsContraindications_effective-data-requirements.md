# Library - WHO Immunization Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* [**Indices**](indices.md)
* [**Artifact Index**](artifacts.md)
* [**IMMZ.D5.DT.Mumps contraindications**](PlanDefinition-IMMZD5DTMumpsContraindications.md)
* **Library**

## Library: Library 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/immunizations/PlanDefinition/IMMZD5DTMumpsContraindications#effective-data-requirements | *Version*:1.0.0 |
| Draft | *Computable Name*:EffectiveDataRequirements |

